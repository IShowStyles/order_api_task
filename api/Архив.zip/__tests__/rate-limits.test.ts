import app from '../src/app';
import request from 'supertest';

describe('Rate Limiting', () => {
  const orderPayload = {
    userId: '00000000-0000-0000-0000-000000000001',
    productId: '00000000-0000-0000-0000-000000000002',
    quantity: 1,
  };

  const LIMIT = 10;

  describe('POST /orders', () => {
    const ip = '1.2.3.4';

    it(`should allow ${LIMIT} requests and return 429 on the ${LIMIT + 1}th`, async () => {
      for (let i = 0; i < LIMIT; i++) {
        const res = await request(app)
          .post('/orders')
          .set('X-Forwarded-For', ip)
          .send(orderPayload);
        expect(res.status).toBe(200);
      }

      // запрос №11 — 429
      const res = await request(app)
        .post('/orders')
        .set('X-Forwarded-For', ip)
        .send(orderPayload);

      expect(res.status).toBe(429);
      expect(res.body.error).toMatch(/Too many requests/i);
    });
  });

  describe('GET /orders', () => {
    const ip = '5.6.7.8';

    it(`should allow ${LIMIT} GETs and return 429 on the ${LIMIT + 1}th`, async () => {
      for (let i = 0; i < LIMIT; i++) {
        const res = await request(app)
          .get('/orders')
          .set('X-Forwarded-For', ip);
        expect(res.status).toBe(200);
      }

      const res = await request(app).get('/orders').set('X-Forwarded-For', ip);

      expect(res.status).toBe(429);
      expect(res.body.error).toMatch(/Too many requests/i);
    });
  });

  describe('GET /users', () => {
    const ip = '9.10.11.12';

    it(`should allow ${LIMIT} GETs and return 429 on the ${LIMIT + 1}th`, async () => {
      // первые LIMIT запросов — 200
      for (let i = 0; i < LIMIT; i++) {
        const res = await request(app).get('/users').set('X-Forwarded-For', ip);
        expect(res.status).toBe(200);
      }

      // запрос №11 — 429
      const res = await request(app).get('/users').set('X-Forwarded-For', ip);

      expect(res.status).toBe(429);
      expect(res.body.error).toMatch(/Too many requests/i);
    });
  });
});

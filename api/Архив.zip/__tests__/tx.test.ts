import request from 'supertest';
import { prisma } from '../src/utils/db';
import app from '../src/app';
import { Prisma } from '@prisma/client';

describe('Transaction Tests: Verify that partial orders do not occur', () => {
  // Используем валидные UUID вместо "XXX_XXX"
  const testUserId = '00000000-0000-0000-0000-000000000001';
  const testProductId = '00000000-0000-0000-0000-000000000002';
  const initialBalance = 100;
  const initialStock = 10;

  beforeAll(async () => {
    await prisma.user.upsert({
      where: { id: testUserId },
      update: {},
      create: {
        id: testUserId,
        name: 'Test User',
        email: 'test@example.com',
        balance: new Prisma.Decimal(initialBalance),
      },
    });
    await prisma.product.upsert({
      where: { id: testProductId },
      update: {},
      create: {
        id: testProductId,
        name: 'Test Product',
        price: new Prisma.Decimal(10),
        stock: initialStock,
      },
    });
  });

  afterAll(async () => {
    await prisma.order.deleteMany({ where: { userId: testUserId } });
    await prisma.user.deleteMany({ where: { id: testUserId } });
    await prisma.product.deleteMany({ where: { id: testProductId } });
  });

  it('should rollback transaction if balance deduction fails and leave stock unchanged', async () => {
    const originalTx = prisma.$transaction;

    prisma.$transaction = async (cb: any) => {
      return await cb({
        user: {
          update: async () => {
            throw new Error('Simulated failure on user update');
          },
        },
        product: {
          update: jest.fn(async () => ({ stock: initialStock })),
        },
        order: {
          create: jest.fn(),
        },
      });
    };

    const res = await request(app).post('/orders').send({
      userId: testUserId,
      productId: testProductId,
      quantity: 1,
    });

    expect(res.status).toBe(500);

    const freshUser = await prisma.user.findUnique({
      where: { id: testUserId },
    });
    const freshProduct = await prisma.product.findUnique({
      where: { id: testProductId },
    });
    expect(Number(freshUser!.balance)).toBe(initialBalance);
    expect(freshProduct!.stock).toBe(initialStock);

    prisma.$transaction = originalTx;
  });
});

import express, { Request, Response, NextFunction } from 'express';
import morgan from 'morgan';
import winston from 'winston';
import { rateLimit } from 'express-rate-limit';
import dotenv from 'dotenv';
import { Prisma } from '@prisma/client';
import { prisma } from './utils/db';
import cors from 'cors';

dotenv.config();
export const app = express();

const logger = winston.createLogger({
  level: 'info',
  transports: [new winston.transports.Console()],
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json(),
  ),
});
app.use(
  morgan('combined', { stream: { write: (msg) => logger.info(msg.trim()) } }),
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(
  cors({
    origin: process.env.FRONTEND_URL || '*',
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  }),
);

const limiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 10,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
});

app.use(limiter);

const UUID_RE =
  /^[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}$/;

app.post(
  '/orders',
  async (
    req: Request<
      {},
      {},
      { userId?: string; productId?: string; quantity?: number }
    >,
    res: Response,
    next: NextFunction,
  ): Promise<void> => {
    let { userId, productId, quantity } = req.body;
    if (!userId || !productId || !quantity) {
      res
        .status(400)
        .json({ error: 'userId, productId and quantity are required.' });
      return;
    }
    userId = userId.replace(/\s+/g, '');
    productId = productId.replace(/\s+/g, '');

    if (!UUID_RE.test(userId)) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    if (!UUID_RE.test(productId)) {
      res.status(404).json({ error: 'Product not found.' });
      return;
    }

    try {
      const user = await prisma.user.findFirst({ where: { id: userId } });
      if (!user) {
        res.status(404).json({ error: 'User not found.' });
        return;
      }
      const product = await prisma.product.findFirst({
        where: { id: productId },
      });
      if (!product) {
        res.status(404).json({ error: 'Product not found.' });
        return;
      }

      const totalPriceStr = new Prisma.Decimal(product.price.toString())
        .mul(quantity)
        .toFixed(2);

      if (new Prisma.Decimal(user.balance.toString()).lt(totalPriceStr)) {
        res.status(403).json({ error: 'Insufficient balance.' });
        return;
      }

      // if (product.stock < quantity) {
      //   res.status(500).json({ error: 'Insufficient stock.' });
      //   throw new Error('Out of stock.');
      // }

      if (product.stock < quantity) {
        throw new Error('Insufficient stock.');
      }

      // const order = await prisma.$transaction(async (tx) => {
      //   const updatedUser = await tx.user.update({
      //     where: { id: userId },
      //     data: { balance: { decrement: new Prisma.Decimal(totalPriceStr) } },
      //   });

      //   const updatedProduct = await tx.product.update({
      //     where: { id: productId },
      //     data: { stock: { decrement: quantity } },
      //   });

      //   if (updatedProduct.stock < 0) {
      //     res.status(500).json({ error: 'Insufficient stock.' });
      //     throw new Error('Insufficient stock for product');
      //   }

      //   if (updatedUser.balance.lt(new Prisma.Decimal(0))) {
      //     res.status(500).json({ error: 'Insufficient balance.' });
      //     throw new Error('Insufficient balance for user');
      //   }

      //   if (!updatedUser || !updatedProduct) {
      //     res.status(500).json({ error: 'Failed to update user or product.' });
      //     throw new Error('Failed to update user or product');
      //   }

      //   const newOrder = await tx.order.create({
      //     data: {
      //       userId,
      //       productId,
      //       quantity,
      //       totalPrice: totalPriceStr,
      //     },
      //   });

      //   if (!newOrder) {
      //     res.status(500).json({ error: 'Failed to create order.' });
      //     throw new Error('Failed to create order');
      //   }
      //   logger.info(`Order created: ${newOrder.id}`, { order: newOrder });
      //   logger.info(`User updated: ${updatedUser.id}`, { user: updatedUser });

      //   return newOrder;
      // });

      try {
        const order = await prisma.$transaction(async (tx) => {
          const updatedUser = await tx.user.update({
            where: { id: userId },
            data: { balance: { decrement: new Prisma.Decimal(totalPriceStr) } },
          });

          const updatedProduct = await tx.product.update({
            where: { id: productId },
            data: { stock: { decrement: quantity } },
          });

          if (updatedProduct.stock < 0) {
            res.status(500).json({ error: 'Insufficient stock.' });
            throw new Error('Insufficient stock for product');
          }

          if (updatedUser.balance.lt(new Prisma.Decimal(0))) {
            res.status(500).json({ error: 'Insufficient balance.' });
            throw new Error('Insufficient balance for user');
          }

          if (!updatedUser || !updatedProduct) {
            res
              .status(500)
              .json({ error: 'Failed to update user or product.' });
            throw new Error('Failed to update user or product');
          }

          const newOrder = await tx.order.create({
            data: {
              userId,
              productId,
              quantity,
              totalPrice: totalPriceStr,
            },
          });

          if (!newOrder) {
            res.status(500).json({ error: 'Failed to create order.' });
            throw new Error('Failed to create order');
          }
          logger.info(`Order created: ${newOrder.id}`, { order: newOrder });
          logger.info(`User updated: ${updatedUser.id}`, { user: updatedUser });

          return newOrder;
        });
        res.status(201).json(order);
      } catch (err: any) {
        logger.error('Error creating order', { error: err.message });
        res.status(500).json({ error: 'Internal server error.' });
        return;
      }

      // if (!order) {
      //   res.status(500).json({ error: 'Failed to create order.' });
      //   return;
      // }

      // logger.info(`Order created: ${order.id}`, { order });
      // res.status(201).json(order);
    } catch (err: any) {
      logger.error('Error creating order', { error: err.message });
      res.status(500).json({ error: 'Internal server error.' });
    }
  },
);

app.get(
  '/orders/:userId',
  async (
    req: Request<{ userId: string }>,
    res: Response,
    next: NextFunction,
  ): Promise<void> => {
    let { userId } = req.params;
    userId = userId.replace(/\s+/g, '');
    if (!UUID_RE.test(userId)) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    try {
      const user = await prisma.user.findUnique({ where: { id: userId } });
      if (!user) {
        res.status(404).json({ error: 'User not found.' });
        return;
      }
      const orders = await prisma.order.findMany({
        where: { userId },
        include: { product: true },
      });
      res.status(200).json(orders);
    } catch (err: any) {
      logger.error('Error fetching orders', { error: err.message });
      res.status(500).json({ error: 'Internal server error.' });
    }
  },
);

app.get('/users', async (req: Request, res: Response) => {
  try {
    const users = await prisma.user.findMany();
    const userIds = users.map((user) => ({
      id: user.id,
      name: user.name,
    }));
    res.status(200).json(userIds);
  } catch (err: any) {
    logger.error('Error fetching users', { error: err.message });
    res.status(500).json({ error: 'Internal server error.' });
  }
});

app.listen(process.env.PORT || 3000, () => {
  logger.info(`Server running on port ${process.env.PORT || 3000}`);
});

export default app;

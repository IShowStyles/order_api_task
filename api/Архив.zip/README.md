# My Express App

This project is a simple Express.js application built with TypeScript, using Prisma ORM for database interactions with MongoDB.

## Project Structure

```
my-express-app
├── src
│   ├── app.ts                # Entry point of the application
│   ├── controllers
│   │   └── index.ts          # Contains the IndexController
│   ├── routes
│   │   └── index.ts          # Sets up application routes
│   └── utils
│       └── db.ts             # Database connection utilities
├── prisma
│   └── schema.prisma         # Prisma schema for the database
├── .env                       # Environment variables
├── package.json               # NPM dependencies and scripts
├── tsconfig.json             # TypeScript configuration
└── README.md                  # Project documentation
```

## Getting Started

1. **Clone the repository:**
   ```
   git clone <repository-url>
   cd my-express-app
   ```

2. **Install dependencies:**
   ```
   npm install
   ```

3. **Set up environment variables:**
   Create a `.env` file in the root directory and add your MongoDB connection string:
   ```
   DATABASE_URL="your_mongodb_connection_string"
   ```

4. **Run the application:**
   ```
   npm run start
   ```

## Scripts

- `start`: Starts the application.
- `dev`: Runs the application in development mode with hot reloading.

## License

This project is licensed under the MIT License.